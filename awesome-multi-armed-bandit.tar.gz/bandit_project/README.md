# A simple bandit project for beginners

This is a course project for SI140 2019 at ShanghaiTech University offered by Prof. Ziyu Shao.

The project specification is [here](./bandit_project.pdf).

[Simulation notebook](https://nbviewer.jupyter.org/github/DerekDick/awesome-multi-armed-bandit/blob/master/bandit_project/three_armed_bandit.ipynb)
